Date.prototype.format = function(fmt) {
    var o = {
        "M+": this.getMonth() + 1, //月份 
        "d+": this.getDate(), //日 
        "h+": this.getHours(), //小时 
        "m+": this.getMinutes(), //分 
        "s+": this.getSeconds(), //秒 
        "q+": Math.floor((this.getMonth() + 3) / 3), //季度 
        "S": this.getMilliseconds() //毫秒 
    };
    if (/(y+)/.test(fmt)) {
        fmt = fmt.replace(RegExp.$1, (this.getFullYear() + "").substr(4 - RegExp.$1.length));
    }
    for (var k in o) {
        if (new RegExp("(" + k + ")").test(fmt)) {
            fmt = fmt.replace(RegExp.$1, (RegExp.$1.length == 1) ? (o[k]) : (("00" + o[k]).substr(("" + o[k]).length)));
        }
    }
    return fmt;
}

$(document).ready(function() {
    $("#output").hide();
    $("#error").hide();
});



$("#openAccount").click(function(e) {
    debugger;
    var clientName = $("#clientName").val();
    var birthDate = $("#birthDay").val();
    var certNum = $("#certNum").val();
    var mobileNo = $("#mobileNo").val();
    var tranTimestamp = (new Date()).format("yyyyMMddhhmmss");
    var tranDate = (new Date()).format("yyyyMMdd");
    var seqNo = "mobitor-" + tranTimestamp;
    var jsonObj = {
        "branchId": "1234567890",
        "company": "CITIBANK",
        "innerData": {
            "acctClass": "2",
            "acctExec": "",
            "acctName": "赵零三",
            "altAcctName": "",
            "ccy": "CNY",
            "clientNo": "1000000004",
            "contactArray": [{
                "documentId": "21050419941017738X1",
                "documentType": "29",
                "linkmanName": "",
                "linkmanType": "",
                "phoneNo1": "13329299911",
                "phoneNo2": ""
            }],
            "passwordArray": [{
                "password": "123456",
                "passwordEffectDate": "20180711"
            }],
            "prodType": "111001",
            "reasonCode": "303",
            "settleArray": [{
                "priority": "1",
                "settleAcctCcy": "CNY",
                "settleAcctName": "赵零三",
                "settleAcctSeqNo": "01",
                "settleBankCode": "CCB001",
                "settleBankFlag": "O",
                "settleBankName": "CCB",
                "settleBaseAcctNo": "6200111155644564",
                "settleClientNo": "1000000001",
                "settleMobilePhone": "13344556456",
                "settleProdType": ""
            }],
            "withdrawArray": [{
                "channelMuster": "SWG"
            }]
        },
        "pubPage": {
            "currentNum": "",
            "order": "",
            "orderBy": "",
            "pageEnd": "",
            "pageStart": "",
            "pgupOrPgdn": "",
            "totalFlag": "",
            "totalNum": "",
            "totalPages": "",
            "totalRows": ""
        },
        "seqNo": seqNo,
        "sign": "2",
        "sourceType": "ALL",
        "systemId": "10",
        "tranDate": tranDate,
        "tranTimestamp": tranTimestamp,
        "userId": "PA001",
        "userLang": "ZH_CN",
        "version": "1.0"
    };

    $.ajax({
        type: "post",
        url: "http://172.24.245.85:8085/apsi/onboarding/openAccount",
        data: jsonObj,
        contentType: "application/json",
        accept: "*/*",
        success: function(response) {
            $("#error").hide();
            $("#output").show();
            $("#output").val("value: " + response.toString())
        },
        error: function(error) {
            $("#output").hide();
            $("#error").show();
            $("#error").html("error:" + error.toString())
        }
    });

})