Date.prototype.format = function(fmt) {
    var o = {
        "M+": this.getMonth() + 1, //月份 
        "d+": this.getDate(), //日 
        "h+": this.getHours(), //小时 
        "m+": this.getMinutes(), //分 
        "s+": this.getSeconds(), //秒 
        "q+": Math.floor((this.getMonth() + 3) / 3), //季度 
        "S": this.getMilliseconds() //毫秒 
    };
    if (/(y+)/.test(fmt)) {
        fmt = fmt.replace(RegExp.$1, (this.getFullYear() + "").substr(4 - RegExp.$1.length));
    }
    for (var k in o) {
        if (new RegExp("(" + k + ")").test(fmt)) {
            fmt = fmt.replace(RegExp.$1, (RegExp.$1.length == 1) ? (o[k]) : (("00" + o[k]).substr(("" + o[k]).length)));
        }
    }
    return fmt;
}

$(document).ready(function() {
    $("#output").hide();
    $("#error").hide();
});

$("#registerCustomer").click(function(e) {
    var clientName = $("#clientName").val();
    var birthDate = $("#birthDay").val();
    var certNum = $("#certNum").val();
    var mobileNo = $("#mobileNo").val();
    var tranTimestamp = (new Date()).format("yyyyMMddhhmmss");
    var tranDate = (new Date()).format("yyyyMMdd");
    var seqNo = "mobitor-" + tranTimestamp;
    var jsonObj = {
        "authFlag": "N",
        "branchId": "1234567890",
        "company": "CITIBANK",
        "innerData": {
            "categoryType": "101",
            "categoryCode": "300",
            "clientName": clientName,
            "address": "WanPing Road, XuHui District, ShangHai",
            "countryLoc": "CHN",
            "countryRisk": "CHN",
            "stateLoc": "SH",
            "ctrlBranch": "1234567890",
            "referenceClientNo": "1000002201",
            "birthDate": birthDate,
            "branchCode": "90001",
            "clientType": "10",
            "inlandOffshore": "I",
            "documentInfoList": [{
                "documentId": certNum,
                "documentType": "23",
                "expiryDate": "20290101",
                "issAuthority": "GAN",
                "issCountry": "CHN",
                "issDate": "20000101",
                "issPlace": "SH",
                "prefFlag": "Y"
            }],
            "contactInfoList": [{
                "contactType": "13",
                "address": "test address",
                "country": "CHN",
                "contactTel": mobileNo,
                "prefFlag": "Y",
                "bicCode": "123321"
            }]
        },
        "pubPage": {
            "currentNum": "",
            "order": "",
            "orderBy": "",
            "pageEnd": "",
            "pageStart": "",
            "pgupOrPgdn": "",
            "totalFlag": "",
            "totalNum": "",
            "totalPages": "",
            "totalRows": ""
        },
        "seqNo": seqNo,
        "sign": "2",
        "sourceType": "ALL",
        "systemId": "10",
        "tranDate": tranDate,
        "tranTimestamp": tranTimestamp,
        "userId": "PA001",
        "userLang": "ZH_CN",
        "version": "1.0"
    };

    $.ajax({
        type: "post",
        url: "http://172.24.245.85:8085/apsi/onboarding/customerRegistering",
        data: jsonObj,
        contentType: "application/json",
        accept: "*/*",
        success: function(response) {
            console.log(response);
            $("#error").hide();
            $("#output").show();
            $("#output").html(response.toString())
        },
        error: function(error) {
            $("#output").hide();
            $("#error").show();
            $("#error").html(error.toString())
        }
    });

})